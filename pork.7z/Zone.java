import java.util.*;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException; 

public class Zone {

    private int number;
    private ArrayList<String> objects = new ArrayList<String>();



    public Zone(int x){
        number = x;
        if(number == 1)
        {
            objects.add("Boogie");
            objects.add("rusty lock");
            objects.add("flimsy gate");
            System.out.println("== THE STY ==\n");
        }
        else if(number == 2)
        {
            objects.add("apple tree");
            objects.add("western pigsty");
            objects.add("house");
            objects.add("woods");
            // System.out.println("==THE FARM==\n");
        }
        else if(number == 3)
        {
            //System.out.println("==THE HOUSE==\n");
            objects.add("study");
            objects.add("living room");
            objects.add("kitchen");
            objects.add("farm");
        }
        else if(number == 4)
        {
            //System.out.println("==THE WOODS==\n");
            objects.add("wolf");

        }
        else if(number == 5)
        {
            objects.add("apple");
            objects.add("lamp");
            objects.add("key");
            objects.add("house");

        }
        else{
            return;
        }
    }

    public void addObject(String x)
    {
        this.objects.add(x);
    }

    public void removeObject(String x)
    {
        this.objects.remove(x);
    }

    public boolean containsObject(String x)
    {
        if(this.objects.contains(x))
        {
            return true;
        }
        else{
            return false;
        }
    }


    public int getNumber(){
        return number;
    }

    public void setNumber(int x){
        number = x;
    }

    public void objectInfo()
    {
       
        System.out.println(objects);

    }

    public void lookAround(int x)
    {
        switch(x)
        {
            case 1:
                // System.out.println("==THE PEN==");
                this.readFile("stydesc.txt");
                System.out.println("The objects you can interact with in the sty are: " + objects);



                break;
            case 2:
                this.readFile("farmdesc.txt");
                System.out.println("The objects you can interact with in the farm are: " + objects);
                break;
            case 3:
                this.readFile("housedesc.txt");
                System.out.println("The objects you can interact with in the house are: " + objects);
                break;
            case 4:
                this.readFile("woodsdesc.txt");
                System.out.println("The objects you can interact with in the woods are: " + objects);
            case 5:
                this.readFile("studydesc.txt");
                System.out.println("The objects you can interact with in the study are: " + objects);
        }
        
    }

    public void readFile(String x)
    {
        try{
            
            File f = new File(x);
            Scanner s = new Scanner(f);
            while(s.hasNextLine())
            {
                String content = s.nextLine();
                System.out.println(content);
            }
            s.close();
        } catch (FileNotFoundException e)
        {
            System.out.println("an error occurred!");
            e.printStackTrace();
        }
        


        
    }

    public void battles(Player p1, Player x, int esc)
    {
        int loop = 1;
        while(loop == 1 && p1.getHealth() > 0 && x.getHealth() > 0)
        {
            System.out.println("=======================================================================");
            System.out.println("HP :" + p1.getHealth() + "/" + p1.getMaxHealth() + "                   |             " + x.getName() + "\'s HP :" + x.getHealth() + "/" + x.getMaxHealth());
            System.out.println("INVENTORY :" + p1.getInven() + "              |");
            System.out.println("=======================================================================");
            System.out.println("What would you like to do?" + "    |");
            System.out.println("[1.Attack]" + "                    |" );
            System.out.println("[2.Use item]" + "                  |");
            System.out.println("[3.Run]" + "                       |");
            Scanner s = new Scanner(System.in);
            String in = s.nextLine();
            
                if(in.equals("1"))
                {

                    int damageDealt = this.randInt((p1.getDamage() + 3), (p1.getDamage() - 3));
                    x.deductHealth(damageDealt);
                    System.out.println("You dealt " + x.getName() + " " + damageDealt + " damage!");

                    int xDamage = x.randInt(x.getDamage() + 3, x.getDamage() - 3);
                    p1.deductHealth(xDamage);
                    System.out.println("You take " + xDamage + " from " + x.getName() + " in return!");

                }
                else if(in.equals("2"))
                {
                    if(p1.getInven().equals("apple"))
                    {
                        p1.levelUp();
                    }
                    else if(p1.getInven().equals("lamp") && x.getMaxHealth() > 100)
                    {
                        System.out.println("With a great shake of your head you toss the lamp at the wolf's paws where the fire begins to immediately spread amongst the dry leaves. A lick of flame catches the wolf's tail");
                        System.out.println("and it lets out a loud yelp before fleeing with a whimper. You have a feeling it will not bother you again. And so between a path of fire and flame you tread your way through the forest and to freedom.");
                        this.readFile("endwin.txt");
                        System.exit(0);
                    }
                    else{
                        System.out.print("You can't use that!");
                    }
                    
                }
                else if(in.equals("3"))
                {
                    if(esc == 0)
                    {
                        System.out.println("You can't escape from this one!");
                        loop = 1;
                    }
                    else{
                        System.out.println("You run away safely!");
                        loop = 0;
                    }
                
                }
                else if(in.equals("exit"))
                {
                    System.exit(0);
                }
                else{
                    System.out.println("You can't do that!");
                }
                    
                
            
            
        }
        if(p1.getHealth() <= 0)
        {
            System.out.println("Unfortunately you have been felled in combat, you lie there slowly succumbing to the persistent tug of death and the world slowly fades to black...");
            System.exit(0);
        }
        else if(x.getHealth() <= 0)
        {
            if(x.getMaxHealth() > 100)
            {
                this.readFile("endwin.txt");
            }
            System.out.println("You have defeated " + x.getName() + " in combat.");
            this.removeObject(x.getName());
            
        }

    }

    public int randInt(int max, int min)
    {
        int x = min + (int)(Math.random() * ((max - min)+1));
        return x;
         
    }

    public void execHunt()
    {
        Scanner s = new Scanner(System.in);
        String command = s.nextLine().toLowerCase();
        String parts[] = command.split(" ");
        if(parts[0].equals("go") && parts[1].equals("to"))
        {
            if(parts[2].equals("apple"))
            {
                number = 2;
                System.out.println("You rush out the house, moving as fast as your stubby legs can carry you and dash to the apple tree, the shrubbery there seems thick enough to hide even an animal as impressively sized as yourself. You dive right in.");
                System.out.println("You wait there so long the sun approaches then surpasses its zenith and begins its slow lilting descent before you gather the courage to step out again. On the bright side you can't hear Master's oafish footsteps any longer.");
            }
            else{
                this.readFile("endingseq2.txt");
                System.exit(0);
            }
        }

    }
    
    public static void main(String[] args) {
        Zone z1 = new Zone(1);
        System.out.println(z1.getNumber());
        z1.objectInfo();
        //z1.readFile("stydesc.txt");
        z1.lookAround(1);
    }
}