public class regItem implements Item {

    private int worth = 0;

    public String getDesc() {

        return "An item";
    }

    public int getWorth() {

        System.out.println("Item is worth: " + this.worth);

        return this.worth;

    }

}
