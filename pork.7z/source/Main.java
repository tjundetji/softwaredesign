import java.util.*;
import java.util.concurrent.TimeUnit;
import java.lang.*;
public class Main{

    private int zNumber;

    public void start()
    {
        
        Player p1 = new Player(100,1,"default",5);
        p1.nameGen();
        zNumber = 1;
        Zone sty = new Zone(1);
        Zone farm = new Zone(2);
        Zone house = new Zone(3);
        Zone woods = new Zone(4);
        Zone study = new Zone(5);
        Player boogie = new Player(30,1,"Boogie",3);
        

        int styLock = 1;
        int farmLock = 1;
        int houseLock = 1;
        int woodsLock = 1;
        int studyLock = 1;

        int tree_apples = 1;
        int kitchen_heal = 1;
        int billie_apple = 1;

       

        int findCounter = 0;

        Scanner s2 = new Scanner(System.in);
        while(true)
        {
            
            String command = s2.nextLine().toLowerCase();
            String[] parts = command.split(" ");
           

            if(!parts[0].matches("attack|i|h|l|c|look|help|1|2|3|go|pick|eat|use|enter|read|run|yes|no|exit|restart|examine|talk|steal"))
            {
                System.out.println("Sorry I don't know what " + command + " means!");
            }
            else if(parts[0].matches("exit"))
            {
                System.exit(0);
            }
            else if(parts[0].matches("look"))
            {
                switch(zNumber)
                {
                    case 1:
                        sty.lookAround(1);
                        break;
                    case 2:
                        farm.lookAround(2);
                        break;
                    case 3:
                        house.lookAround(3);
                        break;
                    case 4:
                        woods.lookAround(4);
                        break;
                    case 5:
                        study.lookAround(5);

                }
                
            }
            else if(parts[0].equals("i"))
            {
                System.out.println("INVENTORY: " + p1.getInven());
            }
            else if(parts[0].equals("h"))
            {
                System.out.println("HEALTH: " + p1.getHealth());
            }
            else if(parts[0].equals("c"))
            {
                System.out.println("CHARACTER INFO ==============");
                p1.getInfo();
            }
            else if(parts[0].equals("l"))
            {
                System.out.println("LEVEL: " + p1.getLevel());
            }
            else if(parts[0].equals("attack"))// && !parts[1].isEmpty())
            {
                
                switch(zNumber)
                {
                    case 1:
                        if(parts[1].equals("boogie"))
                        {
                            sty.battles(p1,boogie, 1);
                        }
                        else if( (parts[1].equals("rusty") || parts[1].equals("lock")) && sty.containsObject("rusty lock"))
                        {
                            System.out.println("You bash your head against the old lock causing a sharp sound that rings around the tranquil farm, fortunately few animals appear to take notice.");
                            System.out.println("The lock however, was not so undisturbed. It snaps, leaving the gate slightly ajar and your path clear.");
                            System.out.println("You can now access THE FARM, enter GO TO FARM when you are ready.");
                            farmLock = 0;
                            sty.removeObject("rusty lock");
                        }
                        else if((parts[1].equals("flimsy") || parts[1].equals("gate")) && sty.containsObject("flimsy gate"))
                        {
                            System.out.println("You run full force at the gate and it shatters into a thousand splinters. The entire farm stirs in response to the harsh noise.");
                            System.out.println("You aren't unscathed however, you feel a light bruising on the top of your head and midriff. That'll hurt in the morning.");
                            System.out.println("You receive 10 damage.");
                            p1.deductHealth(10);
                            System.out.println("You can now access THE FARM, enter GO TO FARM when you are ready.");
                            farmLock = 0;
                            sty.removeObject("flimsy gate");

                        }
                        else{
                            System.out.println("You can't attack that!");
                        }
                    case 2:
                        if(parts[1].equals("apple") && tree_apples == 1)
                        {
                            System.out.println("You notice an apple dangling precariously from a thin twig near the top of the tree. You give the tree a little nudge and it falls to the ground.");
                            farm.addObject("apple");
                            tree_apples = 0;
                        }
                        else if(parts[1].equals("apple") && tree_apples == 0)
                        {
                            System.out.println("All the other apples are too tightly bound to their stems and remain frustratingly out of bite range");
                        }
                }
                



            }
            else if(parts[0].equals("talk") && parts[1].equals("to"))
            {
                
                switch(zNumber)
                {
                    case 1:
                        if(parts[2].equals("boogie") && sty.containsObject("Boogie"))
                        {
                            System.out.println("You call out to Boogie, he raises his head to the sound of your voice. \"What's up? you look so well rested, I'm happy to see that!\" he says with a sleepy grin");
                            sty.readFile("boogielines.txt");
                        }
                        else if(parts[2].equals("boogie") && !sty.containsObject("Boogie"))
                        {
                            System.out.println("Boogie lies unmoving on the sty floor. Flies hover above his warm flesh.");
                            
                        }
            
                    
                }
            }
            else if(parts[0].equals("go") && parts[1].equals("to"))
            {
                if(parts[2].equals("farm") && farmLock == 0 || (parts[2].equals("the") && parts[3].equals("farm") && farmLock == 0))
                {
                    System.out.println("");
                    System.out.println("== THE FARM ==\n");
                    zNumber = 2;
                    styLock = 0;
                    houseLock = 0;
                    woodsLock = 0;
                }
               
                else if(parts[2].equals("sty") && styLock == 0 || (parts[2].equals("the") && parts[3].equals("sty") && styLock == 0))
                {
                    System.out.println("== THE STY ==");
                    zNumber = 1;
                    houseLock = 1;
                    farmLock = 0;
                    woodsLock = 1;
                    studyLock = 1;
                }
               
                else if(parts[2].equals("house") && houseLock == 0 || (parts[2].equals("the") && parts[3].equals("house") && houseLock == 0))
                {
                    System.out.println("");
                    System.out.println("== THE HOUSE ==\n");
                    zNumber = 3;
                    styLock = 1;
                    farmLock = 0;
                    woodsLock = 1;
                    studyLock = 0;
                }
                else if(parts[2].equals("woods") && woodsLock == 0 || (parts[2].equals("the") && parts[3].equals("woods") && woodsLock == 0))
                {
                    System.out.println("");
                    System.out.println("== THE WOODS ==\n");
                    zNumber = 4;
                    styLock = 1;
                    farmLock = 0;
                    houseLock = 1;
                    studyLock = 1;
                    woods.readFile("woodsseq1.txt");
                    Player wolf = new Player(160,5,"wolf",20);
                    woods.battles(p1, wolf, 0);

                }
                else if(parts[2].equals("study") && studyLock == 0 || (parts[2].equals("the") && parts[3].equals("study") && studyLock == 0))
                {
                    System.out.println("");
                    System.out.println("== THE STUDY ==\n");
                    zNumber = 5;
                    styLock = 1;
                    houseLock = 0;
                    farmLock = 1;
                    woodsLock = 1;
                }
                else if(zNumber == 2 && parts[2].equals("apple"))
                {
                    System.out.println("You approach the massive apple tree. It's gnarled trunk looms over you as if to tell you to back off. But you know better, its deep roots and pockmarked skin engenders a sense of comfort and permanence within you. You look at the shrubbery behind it and instantly feel safe.");
                }
                else if(zNumber == 2 && parts[2].equals("western") && billie_apple == 1)
                {
                    System.out.println("You head to the western pigsty where your very old acquaintance Billie greets you.");
                    farm.readFile("billielines.txt");
                    Scanner bs = new Scanner(System.in);
                    String answer = bs.nextLine();
                    if(answer.equals("1"))
                    {
                        System.out.println("\"Perfect! Oink!\" Billie lets out a hearty chuckle again.");
                        farm.readFile("billieriddle.txt");
                        Scanner ra = new Scanner(System.in);
                        String riddleAnswer = bs.nextLine();   
                        if(riddleAnswer.toLowerCase().equals("none") || riddleAnswer.toLowerCase().equals("zero") || riddleAnswer.toLowerCase().equals("nothing") || riddleAnswer.toLowerCase().equals("0") )
                        {
                            System.out.println("Billie makes some sort of grumbling noise and disappears before reappearing with an apple. He rolls it toward you.\n");
                            System.out.println("\"Go on then. Take it and leave!\" Billie slinks back into the early morning shadows of his sty.");
                            farm.addObject("apple");
                            billie_apple = 0;
                        }
                        else{
                            System.out.println("\"Wrong answer!!\" Billie squeals in delight! You walk up to him and he thumps you over the head.");
                            System.out.println("You head back to the farm center. \"Better luck next time\" Billie calls out to you as you leave. His raucous laughter haunts you all the way back.");
                            System.out.println("You receive 10 damage.");
                            p1.deductHealth(10);
                        }
                    }
                    else if(answer.equals("2"))
                    {
                        System.out.println("\"Aw darn, well thats too bad then\" mutters Billie. He seems disheartened.");
                    }


                }
                else if(zNumber == 3 && parts[2].equals("living"))
                {
                    house.readFile("livingroomseq.txt");
                    house.execHunt();
                }
                else if(zNumber == 3 && parts[2].equals("kitchen"))
                {
                    if(kitchen_heal == 1)
                    {
                        System.out.println("All your exploring has come to fruition at last! You spot a pumpkin pie cooling off on a sill. Needless to say your tummy feels very pleased at this discovery.");
                        System.out.println("[All your health has been restored]");
                        kitchen_heal  = 0;
                        p1.setHealth(p1.getMaxHealth());
                    }
                    else{
                        System.out.println("Just an empty pumpkin pie graveyard where the ghost of one such pie haunts your tastebuds.");
                    }
                }
                
                else{
                    System.out.println("You can't go there right now!");
                }
            }
            else if(parts[0].equals("steal") && parts[1].equals("from") && parts[2].equals("boogie"))
            {
                System.out.println("You steal Boogie's apple right from under his nose, he isn't going to be pleased when he wakes up.");
                p1.swapItem("apple");
            }
            else if(parts[0].equals("pick") && parts[1].equals("up"))
            {
                switch(zNumber)
                {
                    case 2:
                        if(parts[2].equals("apple") && farm.containsObject("apple"))
                        {
                            if(!p1.getInven().equals("empty"))
                            {
                                farm.addObject(p1.getInven());
                                p1.swapItem("apple");
                                System.out.println("You pick up the apple with your mouth, dropping whatever item was held there previously if any at all.");
                                farm.removeObject("apple");
                            }
                            else{
                                p1.swapItem("apple");
                                System.out.println("You pick up the apple with your mouth, dropping whatever item was held there previously if any at all.");
                                farm.removeObject("apple");
                            }
                            
                        }
                    case 5:
                        if(parts[2].equals("apple") && study.containsObject("apple"))
                        {
                            if(!p1.getInven().equals("empty"))
                            {
                                if(p1.getInven().equals("lamp"))
                                {
                                    study.readFile("endseq1.txt");
                                    System.exit(0);
                                }
                                else{
                                    study.addObject(p1.getInven());
                                    p1.swapItem("apple");
                                    System.out.println("You pick up the apple with your mouth, dropping whatever item was held there previously if any at all.");
                                    study.removeObject("apple");
                                }
                                
                            }
                            else{
                                p1.swapItem("apple");
                                System.out.println("You pick up the apple with your mouth, dropping whatever item was held there previously if any at all.");
                                study.removeObject("apple");
                            }
                        }
                        if(parts[2].equals("lamp") && study.containsObject("lamp"))
                        {
                            if(!p1.getInven().equals("empty"))
                            {
                                study.addObject(p1.getInven());
                                p1.swapItem("lamp");
                                System.out.println("You pick up the lamp with your mouth, dropping whatever item was held there previously if any at all.");
                                study.removeObject("lamp");
                            }
                            else{
                                p1.swapItem("lamp");
                                System.out.println("You pick up the lamp with your mouth, dropping whatever item was held there previously if any at all.");
                                study.removeObject("lamp");
                            }
                        }
                        if(parts[2].equals("key") && study.containsObject("key"))
                        {
                            if(!p1.getInven().equals("empty"))
                            {
                                if(p1.getInven().equals("lamp"))
                                {
                                    study.readFile("endseq1.txt");
                                    //study.readFile("credits.txt");
                                    System.exit(0);
                                }
                                else{
                                    study.addObject(p1.getInven());
                                    p1.swapItem("key");
                                    System.out.println("You pick up the key with your mouth, dropping whatever item was held there previously if any at all.");
                                    study.removeObject("key");
                                }
                                
                            }
                            else{
                                p1.swapItem("key");
                                System.out.println("You pick up the key with your mouth, dropping whatever item was held there previously if any at all.");
                                study.removeObject("key");
                            }
                        }


                }
            }
            else if(parts[0].equals("eat"))
            {
                if(parts[1].equals("apple") && p1.getInven().equals("apple"))
                {
                    p1.levelUp();
                    p1.swapItem("empty");
                }
                else if(parts[1].equals("oat") && p1.getInven().equals("oat"))
                {
                    p1.setHealth(p1.getMaxHealth());
                    System.out.println("Your health has been restored!");
                    p1.swapItem("empty");
                }
                else{
                    System.out.println("You can't eat that!");
                }
            }



            else if(parts[0].equals("help"))
            {
                System.out.println("The commands you can enter are: ");
                sty.readFile("helpcommands.txt");
            }

            
        }
        
    }

    public static void main(String[] args)
    {
        Main m = new Main();
        m.start();
        
    }
}