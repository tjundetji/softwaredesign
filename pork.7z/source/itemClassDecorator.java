abstract class itemClassDecorator implements Item {

    protected Item tempItem;


     

    public itemClassDecorator(Item newItem){

        tempItem = newItem;

    }

    public String getDesc() {

        return tempItem.getDesc();

    }

    public int getWorth() {

        return tempItem.getWorth();

    }

}
