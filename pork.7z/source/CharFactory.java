import java.util.HashMap;
import java.util.*;


public class CharFactory
{
    public static HashMap<String, Player> playerNameHashMap = new HashMap<String,Player>();

    public static Player getPlayer(String name)
    {
       Player p = (Player)playerNameHashMap.get(name);
       if(p == null)
       {
           p = new Player(name);
           playerNameHashMap.put(name,p);
       }
       return p;
    }



    public static void main(String[] args)
    {
    
        //just for testing:
        Player c = CharFactory.getPlayer("ab");
        Player d = CharFactory.getPlayer("abc");
        Player b = CharFactory.getPlayer("ab");
        System.out.println(b.toString());
        System.out.println(playerNameHashMap.keySet());


    }

}