public class ItemTest {
    public static void main(String[] args){
   

        Item basicItem = new epic(new regItem());

        System.out.println("Description: " + basicItem.getDesc());

        System.out.println("Sell price: " + basicItem.getWorth());

    }

}
