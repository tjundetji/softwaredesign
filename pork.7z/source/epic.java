public class epic extends itemClassDecorator {

    public epic(Item newItem) {

        super(newItem);


    }


    public String getDesc(){

        return tempItem.getDesc() + " [EPIC]";

    }

    public int getWorth(){

        
        return tempItem.getWorth() + 30;

    }

}
