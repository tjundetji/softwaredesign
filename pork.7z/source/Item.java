public interface Item {
    

    public String getDesc();

    public int getWorth();


}
