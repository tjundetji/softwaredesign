import java.util.*;
import java.lang.*;
public class Player {

    private static String name;
    private int level;
    private String inventory;
    private int health;
    private int damage;
    private int maxHealth;
    private int alive = 1;
    // private int maxdamage = (this.damage + 3);
    // private int mindamage = (this.damage - 3);


    public Player(int x, int y, String n, int d){
        maxHealth = x;
        health = maxHealth;
        name = n;
        level = y;
        inventory = "empty";
        damage = d;
    }
    public Player()
    {
        maxHealth = 100;
        health = 100;
        name = "default";
        level = 1;
        inventory = "empty";
        damage = 5;

    }

    public void deductHealth(int x)
    {
        health = health - x;
    }

    public void increaseHealth(int x)
    {
        if(health < maxHealth)
        {
            health = health + x;
        }
        else{
            return;
        }
        
    }

    public int getHealth()
    {
        return health;
    }
    public void setHealth(int x)
    {
        health = x;
    }

    public int getMaxHealth()
    {
        return maxHealth;
    }

        // HEALTH SECTION

    public String getName()
    {
        return name;
    }

    public void setName(String x)
    {
        name = x;
    }
    

    public void nameGen()
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Your eyelids flutter open as you awaken from your deep slumber, you feel groggy but still manage to prop yourself up on two short, stubby legs. 'Ooooghink' a garbled croak escapes your throat as you realize your piggish intelligence has caused you to forget your name again, what is your name? ");
        String username = s.nextLine();
        name = username;
        
        System.out.println("Ah that's right your name is " + name + "! It all comes rushing back.");
        System.out.println("Before you get further lost in reflection you notice the cramped pen awash with a gentle orange glow, a harbinger of the rapidly approaching dawn.\n");
        System.out.println("[enter \'look around\' or \'help\' to help you get started!");
    }


        // NAME SECTION ^^

    public void setLevel(int x)
    {
        if(level <= 10)
        {
            level = x;
        }
        else{
            return;
        }
    }

    public void levelUp()
    {
        if(level <= 10)
        {
            System.out.println("You feel a new strength coursing through your body, your skin seems tougher, your trotters firmer, the hairs on your backside appear longer than before. You feel healthier than ever.");
            level += 1;
            maxHealth += 10;
            health = maxHealth;
            damage += 5;
        }
        else{
            health = maxHealth;
            return;
        }
        
    }

    public int getLevel()
    {
        return level;
    }

        // LEVEL SECTION ^^

    public String getInven()
    {
        return inventory;
    }

    public void swapItem(String x)
    {
        inventory = x;
    }

        // INVENTORY SECTION ^^

    public void setDamage(int x)
    {
        damage = x;
    }

    public int getDamage()
    {
        return damage;
    }

    public int randInt(int max, int min)
    {
        int x = min + (int)(Math.random() * ((max - min)+1));
        return x;
         
    }

        // DAMAGE SECTION ^^

    public void getInfo()
    {
        System.out.println("Health : " + this.getHealth());
        System.out.println("Inventory : " + this.getInven());
        System.out.println("Attack damage: " + this.getDamage());
        System.out.println("Level : " + this.getLevel());
    }
 
    



    public static void main(String[] args)
    {
        Player p = new Player();
        p.getInfo();
        System.out.println("\n");

        p.levelUp();
        p.getInfo();
        

        // p.nameGen();
        // System.out.println("my name is " + name);

    }
}