public class test {
    private int x;
    public void setX(int y)
    {
        x = y;
    }
}